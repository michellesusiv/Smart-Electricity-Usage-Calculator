const form = document.getElementById('applianceForm');
const list = document.getElementById('applianceList');
const rateInput = document.getElementById('rate');
const STORAGE_KEY = 'electricity-appliances-v1';

let appliances = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
let chart;

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appliances));
  render();
}

function render() {
  const rate = Math.max(0, Number(rateInput.value) || 0);
  const dailyTotal = appliances.reduce((sum, a) => sum + (a.watts * a.hours / 1000), 0);
  const monthlyTotal = dailyTotal * 30;

  document.getElementById('dailyEnergy').textContent = `${dailyTotal.toFixed(2)} kWh`;
  document.getElementById('monthlyEnergy').textContent = `${monthlyTotal.toFixed(2)} kWh`;
  document.getElementById('monthlyCost').textContent = `₹${(monthlyTotal * rate).toFixed(2)}`;

  if (!appliances.length) {
    list.innerHTML = '<p class="empty">No appliances added yet.</p>';
  } else {
    list.innerHTML = '';
    appliances.forEach(item => {
      const row = document.createElement('article');
      row.className = 'appliance';
      const info = document.createElement('div');
      const name = document.createElement('h3');
      name.textContent = item.name;
      const detail = document.createElement('p');
      const daily = item.watts * item.hours / 1000;
      detail.textContent = `${item.watts} W · ${item.hours} hours/day · ${daily.toFixed(2)} kWh/day`;
      info.append(name, detail);
      const remove = document.createElement('button');
      remove.className = 'remove';
      remove.textContent = 'Remove';
      remove.addEventListener('click', () => {
        appliances = appliances.filter(a => a.id !== item.id);
        save();
      });
      row.append(info, remove);
      list.append(row);
    });
  }
  updateChart();
}

function updateChart() {
  if (typeof Chart === 'undefined') return;
  const labels = appliances.map(a => a.name);
  const values = appliances.map(a => a.watts * a.hours / 1000);
  if (chart) chart.destroy();
  chart = new Chart(document.getElementById('usageChart'), {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Daily energy (kWh)', data: values }] },
    options: {
      responsive: true,
      plugins: { legend: { display: true } },
      scales: { y: { beginAtZero: true, title: { display: true, text: 'kWh per day' } } }
    }
  });
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const name = document.getElementById('applianceName').value.trim();
  const watts = Number(document.getElementById('watts').value);
  const hours = Number(document.getElementById('hours').value);
  if (!name || !Number.isFinite(watts) || watts <= 0 || !Number.isFinite(hours) || hours <= 0 || hours > 24) {
    alert('Enter a name, a positive wattage, and usage between 0 and 24 hours.');
    return;
  }
  appliances.push({
    id: (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()),
    name, watts, hours
  });
  save();
  form.reset();
});

rateInput.addEventListener('input', render);
render();
