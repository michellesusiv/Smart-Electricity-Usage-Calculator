# Smart Electricity Usage Calculator

A responsive web application that estimates household electricity consumption and cost using appliance power ratings and daily usage hours.

## Features
- Add household appliances with wattage and hours of use per day
- Calculate daily and estimated 30-day energy use in kWh
- Estimate monthly cost using an editable per-unit tariff
- Visualize daily energy use with a bar chart
- Remove appliances
- Save appliance data in browser Local Storage

## Calculation
Daily energy (kWh) = Power (W) × Usage hours per day ÷ 1000

Estimated monthly energy = Daily energy × 30

Estimated monthly cost = Monthly energy × Rate per unit

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Add appliances and enter your electricity rate.

The chart uses Chart.js from a CDN, so an internet connection is needed for the chart to load. The calculator itself works in the browser.

## Disclaimer
This project provides an estimate for learning purposes. Actual electricity bills depend on the applicable tariff, slab rates, fixed charges, taxes and other fees.
